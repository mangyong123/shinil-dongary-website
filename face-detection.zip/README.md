# 얼굴 인식 프로그램 (사진 및 카메라)

Python과 OpenCV를 사용하여 이미지 파일 또는 웹캠 영상에서 얼굴을 인식합니다.

## 실행 방법

### 📷 1. 사진에서 얼굴 인식

```bash
python face_image_detect.py
```

### 🎥 2. 실시간 카메라에서 얼굴 인식

```bash
python face_camera_detect.py
```

## 설치

```bash
pip install -r requirements.txt
```

## 필요 라이브러리

- OpenCV
